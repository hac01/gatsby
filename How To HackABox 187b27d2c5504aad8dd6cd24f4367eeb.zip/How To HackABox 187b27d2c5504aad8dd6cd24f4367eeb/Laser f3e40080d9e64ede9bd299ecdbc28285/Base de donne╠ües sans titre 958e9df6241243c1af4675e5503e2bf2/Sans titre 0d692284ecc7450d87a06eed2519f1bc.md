# Sans titre

Files: https://0xdf.gitlab.io/icons/first-blood-user.png, https://www.hackthebox.eu/badge/image/52045
Laser: 00 days, 00 hours, 04 mins, 04 seconds