# Base Points

Laser: Insane [50]