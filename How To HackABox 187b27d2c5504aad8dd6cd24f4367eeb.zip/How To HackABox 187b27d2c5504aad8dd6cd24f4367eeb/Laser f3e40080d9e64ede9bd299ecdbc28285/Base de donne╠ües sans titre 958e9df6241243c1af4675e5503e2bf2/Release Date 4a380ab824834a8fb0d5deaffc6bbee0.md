# Release Date

Laser: https://twitter.com/hackthebox_eu/status/1291410874155044864