# Recon Notes

OSCP Like: No
Points: 0
Root Flag: No
Status: Not Reviewed
User Flag: No

[1:1 Notes](Recon%20Notes%20f0e97150cbb744fe9bd9392841ef9d19/1%201%20Notes%20e712014237ad45179aadbc0efb9704fa.md)