# Base Points

Lightweight: Medium [30]