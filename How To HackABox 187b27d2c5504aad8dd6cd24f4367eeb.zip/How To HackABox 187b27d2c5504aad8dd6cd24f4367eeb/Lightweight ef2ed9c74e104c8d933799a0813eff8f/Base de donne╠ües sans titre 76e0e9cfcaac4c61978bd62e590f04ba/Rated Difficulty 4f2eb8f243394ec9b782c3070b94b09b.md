# Rated Difficulty

Files: https://0xdf.gitlab.io/img/lightweight-diff.png